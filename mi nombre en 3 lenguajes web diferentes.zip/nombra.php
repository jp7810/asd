<html>
    <head>
        <title>clase software 2</title>
    </head>
    <body>
	<?php
	echo"john edwin carreño";
	?>
    </body>
</html>
